/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_woocommerce_log`; */
/* PRE_TABLE_NAME: `1749658124_wp_woocommerce_log`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1749658124_wp_woocommerce_log` ( `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `timestamp` datetime NOT NULL, `level` smallint(4) NOT NULL, `source` varchar(200) NOT NULL, `message` longtext NOT NULL, `context` longtext DEFAULT NULL, PRIMARY KEY (`log_id`), KEY `level` (`level`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
