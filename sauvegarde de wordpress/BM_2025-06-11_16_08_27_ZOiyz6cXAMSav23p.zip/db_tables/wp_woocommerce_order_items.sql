/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_woocommerce_order_items`; */
/* PRE_TABLE_NAME: `1749658124_wp_woocommerce_order_items`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1749658124_wp_woocommerce_order_items` ( `order_item_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `order_item_name` text NOT NULL, `order_item_type` varchar(200) NOT NULL DEFAULT '', `order_id` bigint(20) unsigned NOT NULL, PRIMARY KEY (`order_item_id`), KEY `order_id` (`order_id`)) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1749658124_wp_woocommerce_order_items` (`order_item_id`, `order_item_name`, `order_item_type`, `order_id`) VALUES (3,'ENTREE 1 jour','line_item',102),(4,'ENTREE 1 jour','line_item',148),(5,'ENTREE 3 jours','line_item',152),(7,'ENTREE 3 jours','line_item',232),(8,'ENTREE 3 jours','line_item',238),(9,'ENTREE 3 jours','line_item',239),(10,'ENTREE 1 jour','line_item',241),(12,'ENTREE 3 jours','line_item',242),(13,'ENTREE 1 jour','line_item',242),(14,'ENTREE 3 jours','line_item',249),(15,'ENTREE 3 jours','line_item',250),(16,'ENTREE 3 jours','line_item',257),(17,'ENTREE 3 jours','line_item',258),(19,'ENTREE 3 jours','line_item',260),(20,'ENTREE 1 jour','line_item',308),(22,'ENTREE 3 jours','line_item',332),(23,'ENTREE 3 jours','line_item',345),(24,'ENTREE 3 jours','line_item',346);
