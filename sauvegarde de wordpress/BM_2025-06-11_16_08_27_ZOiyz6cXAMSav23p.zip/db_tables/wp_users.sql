/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_users`; */
/* PRE_TABLE_NAME: `1749658124_wp_users`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1749658124_wp_users` ( `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `user_login` varchar(60) NOT NULL DEFAULT '', `user_pass` varchar(255) NOT NULL DEFAULT '', `user_nicename` varchar(50) NOT NULL DEFAULT '', `user_email` varchar(100) NOT NULL DEFAULT '', `user_url` varchar(100) NOT NULL DEFAULT '', `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00', `user_activation_key` varchar(255) NOT NULL DEFAULT '', `user_status` int(11) NOT NULL DEFAULT 0, `display_name` varchar(250) NOT NULL DEFAULT '', PRIMARY KEY (`ID`), KEY `user_login_key` (`user_login`), KEY `user_nicename` (`user_nicename`), KEY `user_email` (`user_email`)) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1749658124_wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES (1,'admin','$wp$2y$10$kVSTWRP4BYjc6dXlOyJ8au/SnenwcnaM079ISmhod0W/vepcUd1Nm','admin','petitcrapo@hotmail.com','https://nationsoundluc.rf.gd/wp','2024-05-31 07:11:38','',0,'admin'),(2,'client','$P$Bj5D5QR9/qijhDaBPyacDijs1LE8YS/','client','client@client.com','','2024-09-19 07:33:40','',0,'client');
