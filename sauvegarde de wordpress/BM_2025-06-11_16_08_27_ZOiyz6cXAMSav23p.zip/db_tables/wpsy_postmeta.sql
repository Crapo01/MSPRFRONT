/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wpsy_postmeta`; */
/* PRE_TABLE_NAME: `1749658124_wpsy_postmeta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1749658124_wpsy_postmeta` ( `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `post_id` bigint(20) unsigned NOT NULL DEFAULT 0, `meta_key` varchar(255) DEFAULT NULL, `meta_value` longtext DEFAULT NULL, PRIMARY KEY (`meta_id`), KEY `post_id` (`post_id`), KEY `meta_key` (`meta_key`(191))) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1749658124_wpsy_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES (1,2,'_wp_page_template','default'),(2,3,'_wp_page_template','default');
