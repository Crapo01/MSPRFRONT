/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wc_product_download_directories`; */
/* PRE_TABLE_NAME: `1749658124_wp_wc_product_download_directories`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1749658124_wp_wc_product_download_directories` ( `url_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `url` varchar(256) NOT NULL, `enabled` tinyint(1) NOT NULL DEFAULT 0, PRIMARY KEY (`url_id`), KEY `url` (`url`(191))) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
INSERT INTO `1749658124_wp_wc_product_download_directories` (`url_id`, `url`, `enabled`) VALUES (1,'file://C:/xampp/htdocs/ns_hl_wp/wp-content/uploads/woocommerce_uploads/',1),(2,'https://nationsoundluc.rf.gd/wp/wp-content/uploads/woocommerce_uploads/',1),(3,'https://nationsoundluc.rf.gd/wp/wp-content/uploads/2024/05/',1),(4,'https://nationsoundluc.rf.gd/wpdb/wp-content/uploads/2024/05/',1);
