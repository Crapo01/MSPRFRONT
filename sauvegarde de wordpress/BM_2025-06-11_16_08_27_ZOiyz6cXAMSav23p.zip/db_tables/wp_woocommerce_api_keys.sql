/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_woocommerce_api_keys`; */
/* PRE_TABLE_NAME: `1749658124_wp_woocommerce_api_keys`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1749658124_wp_woocommerce_api_keys` ( `key_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `user_id` bigint(20) unsigned NOT NULL, `description` varchar(200) DEFAULT NULL, `permissions` varchar(10) NOT NULL, `consumer_key` char(64) NOT NULL, `consumer_secret` char(43) NOT NULL, `nonces` longtext DEFAULT NULL, `truncated_key` char(7) NOT NULL, `last_access` datetime DEFAULT NULL, PRIMARY KEY (`key_id`), KEY `consumer_key` (`consumer_key`), KEY `consumer_secret` (`consumer_secret`)) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;
